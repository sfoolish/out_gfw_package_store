package p

import "testing"

func TestF(t *testing.T) {
	F()
}
